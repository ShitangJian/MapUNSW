package com.example.cris.programplaner;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private ExpandableListView listview;
    private ExpandListViewAdapter adapter;
    private List<ExpandData> datalist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = (DrawerLayout) findViewById(R.id.DrawerLayout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.Open,R.string.Close);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.menu);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        testData();

        listview = findViewById(R.id.contacts_expandlistview);
        adapter = new ExpandListViewAdapter(this, listview, datalist);
        listview.setAdapter(adapter);

    }

    private void testData(){
        ExpandData expandData = new ExpandData();
        expandData.setName("Program Preview");
        ArrayList<ChildData> arr = new ArrayList<>();
        arr.add(new ChildData("111"));
        arr.add(new ChildData("2222"));
        expandData.setMenus(arr);
        datalist.add(expandData);

        ExpandData expandData2 = new ExpandData();
        expandData2.setName("Course OutLines");
        ArrayList<ChildData> arr2 = new ArrayList<>();
        arr2.add(new ChildData("111"));
        arr2.add(new ChildData("2222"));
        expandData2.setMenus(arr2);
        datalist.add(expandData2);

        ExpandData expandData3 = new ExpandData();
        expandData3.setName("Change Plan");
        ArrayList<ChildData> arr3 = new ArrayList<>();
        arr3.add(new ChildData("Change1"));
        arr3.add(new ChildData("Change2"));
        expandData3.setMenus(arr3);
        datalist.add(expandData3);
    }
    //按返回键 收起 DrawerLayout
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
            drawerLayout.closeDrawer(Gravity.LEFT);
        } else {
            super.onBackPressed();
        }
    }
}
