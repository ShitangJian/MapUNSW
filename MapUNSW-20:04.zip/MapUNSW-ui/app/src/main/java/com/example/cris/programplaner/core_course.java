package com.example.cris.programplaner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class core_course extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_core_course);
    }
}
