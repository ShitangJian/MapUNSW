package com.example.cris.programplaner.model;

public class choose_term {

}
