package com.example.cris.programplaner.model;

import java.util.List;


public class ChildData {
    private String name;

    public ChildData(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
